import abi from "./Transactions.json";

export const contractAddress = "0xD6E9fDd4E2a9660a09DfB4c7F0c9f12Cc9F04705";
export const contractABI = abi.abi;